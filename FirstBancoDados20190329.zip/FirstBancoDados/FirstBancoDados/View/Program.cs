﻿using FirstBancoDados.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstBancoDados
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean continuar = true;
            string op;
            do
            {
                Menu.Imprimir();
                op = Console.ReadLine();
                Console.Clear();
                switch (op)
                {
                    case "0":
                        continuar = false;
                        break;
                    case "1":
                        Cadastrar.CadastrarCliente();
                        break;
                    default:
                        Console.WriteLine("OP Inválida!");
                        break;
                }
            } while (continuar);

            Menu.Finalizar();
        }
    }
}
/* 
    install-package EntityFramework   
    // uninstall-package Entity-Framework
    // enable-migrations
    // add-migration
    // update-database
*/
