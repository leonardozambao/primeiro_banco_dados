﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstBancoDados.View
{
    class Menu
    {
        public static void Imprimir()
        {
            Console.WriteLine("\n***************************************");
            Console.WriteLine("1 - Cadastrar Cliente");
            Console.WriteLine("2 - Listar Clientes");
            Console.WriteLine("3 - Listar Cliente por CPF");
            Console.WriteLine("4 - Remover Cliente");
            Console.WriteLine("5 - Alterar Cliente");
            Console.WriteLine("0 - Finalizar");
        }
        public static void Finalizar()
        {
            Console.WriteLine("***************************************");
            Console.WriteLine("Programa encerrado");
            Console.ReadKey();
        }
    }
}
