﻿using FirstBancoDados.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstBancoDados.View
{
    class Cadastrar
    {
        Context ctx = new Context();
        public static void CadastrarCliente()
        {
            Context ctx = new Context();
            /*Cliente c = new Cliente()
            {
                Nome = "Leonardo",
                Cpf = "11418205958",
                DataNasc = DateTime.Now,
                Genero = "M"
            };*/
            Cliente c = new Cliente();
            Console.WriteLine("informe o nome: ");
            c.Nome = Console.ReadLine();
            Console.WriteLine("informe o cpf:");
            c.Cpf = Console.ReadLine();
            c.DataNasc = DateTime.Now;
            Console.WriteLine("informe o genero:");
            c.Genero = Console.ReadLine();

            ctx.Clientes.Add(c);
            ctx.SaveChanges();
            Console.WriteLine("foi sapoha");
        }
    }
}
