﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstBancoDados.Model
{
    /// <summary>
    /// Essa classe representa o banco de dados da aplicação e o EntityFramework
    /// </summary>
    class Context : DbContext
    {
        public Context() : base("DbCadastro") { } //renomear o banco 
        public DbSet<Cliente> Clientes { get; set; }

        // console
        // install-package Entity-Framework
        // uninstall-package Entity-Framework
        // enable-migrations | just once
        // add-migration
        // update-database -verbose
    }
}
