﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstBancoDados.Model
{
    [Table("Clientes")] //renomear a tabela no banco de dados
    class Cliente
    {
        [Key] // indicar qual será a chave primária (não necessária nesse caso)
        public int ClienteId { get; set; }
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public DateTime DataNasc { get; set; }
        public string Genero { get; set; }
        public override string ToString()
        {
            return "Nome: " + Nome + "\nCPF: " + Cpf;
        }
    }
}
