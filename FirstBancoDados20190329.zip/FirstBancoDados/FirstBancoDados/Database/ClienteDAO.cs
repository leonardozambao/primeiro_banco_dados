﻿using FirstBancoDados.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstBancoDados.Database
{
    class ClienteDAO
    {
        private static Context ctx = new Context();
        public static void CadastrarCliente(Cliente c)
        {
            ctx.Clientes.Add(c);
            ctx.SaveChanges();
        }
        public static List<Cliente> RetornarCLientes()
        {
            return ctx.Clientes.ToList();
        }
    }
}
